function [A]=vec(A)

A=A(:);